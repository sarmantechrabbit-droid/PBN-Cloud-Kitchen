export const experiments = [
  { id: 'EXP-001', recipe: 'Butter Chicken v3.2',  version: 'v3.2', date: '2024-12-14', chef: 'Ravi Kumar',   status: 'Completed', aiScore: 96, batchNo: 'BATCH-2024-001', temp: 185, timing: 45 },
  { id: 'EXP-002', recipe: 'Paneer Tikka v2.1',    version: 'v2.1', date: '2024-12-13', chef: 'Priya Shah',   status: 'Pending',  aiScore: 78, batchNo: 'BATCH-2024-002', temp: 220, timing: 30 },
  { id: 'EXP-003', recipe: 'Dal Makhani v5.0',     version: 'v5.0', date: '2024-12-12', chef: 'Amit Patel',   status: 'Completed', aiScore: 42, batchNo: 'BATCH-2024-003', temp: 160, timing: 120 },
  { id: 'EXP-004', recipe: 'Biryani v4.3',          version: 'v4.3', date: '2024-12-11', chef: 'Sunita Rao',   status: 'Completed', aiScore: 91, batchNo: 'BATCH-2024-004', temp: 190, timing: 60 },
  { id: 'EXP-005', recipe: 'Chole Bhature v1.8',   version: 'v1.8', date: '2024-12-10', chef: 'Vikram Nair',  status: 'Pending',  aiScore: 65, batchNo: 'BATCH-2024-005', temp: 200, timing: 25 },
  { id: 'EXP-006', recipe: 'Palak Paneer v3.0',    version: 'v3.0', date: '2024-12-09', chef: 'Meena Joshi',  status: 'Completed', aiScore: 88, batchNo: 'BATCH-2024-006', temp: 175, timing: 35 },
  { id: 'EXP-007', recipe: 'Chicken Korma v2.5',   version: 'v2.5', date: '2024-12-08', chef: 'Ravi Kumar',   status: 'Completed', aiScore: 93, batchNo: 'BATCH-2024-007', temp: 180, timing: 50 },
  { id: 'EXP-008', recipe: 'Aloo Gobi v1.2',        version: 'v1.2', date: '2024-12-07', chef: 'Priya Shah',   status: 'Completed', aiScore: 38, batchNo: 'BATCH-2024-008', temp: 170, timing: 40 },
]

export const aiAnalysis = [
  {
    id: 'EXP-001',
    recipe: 'Gulab Jamun Classic',
    batchNo: 'B-2024-001',
    date: 'Mar 1, 2024',
    temp: '180°C',
    timing: '15m',
    expTexture: 'Soft',
    actTexture: 'Soft-Medium',
    expYield: '95%',
    actYield: '93%',
    variance: 2.1,
    varianceStatus: 'Acceptable - minor deviation',
    expTaste: 9.2,
    actTaste: 9,
    submittedBy: 'Ahmad Raza',
    version: 'v2.1',
    status: 'Completed',
    risk: 'Low',
    remarks: 'Minor variance in texture, within acceptable range.',
    files: ['dish_gulab.jpg', 'process_log_001.pdf']
  },
  {
    id: 'EXP-002',
    recipe: 'Barfi Premium',
    batchNo: 'B-2024-002',
    date: 'Mar 5, 2024',
    temp: '165°C',
    timing: '20m',
    expTexture: 'Firm',
    actTexture: 'Firm',
    expYield: '88%',
    actYield: '89%',
    variance: 0.8,
    varianceStatus: 'Ideal - no deviation',
    expTaste: 8.5,
    actTaste: 8.6,
    submittedBy: 'Priya Shah',
    version: 'v1.4',
    status: 'Completed',
    risk: 'Low',
    remarks: 'Excellent consistency across all parameters.',
    files: ['barfi_final.png']
  },
  {
    id: 'EXP-003',
    recipe: 'Jalebi Crispy',
    batchNo: 'B-2024-003',
    date: 'Mar 8, 2024',
    temp: '200°C',
    timing: '8m',
    expTexture: 'Crispy',
    actTexture: 'Semi-Crispy',
    expYield: '92%',
    actYield: '87%',
    variance: 15.4,
    varianceStatus: 'Review Required - texture variance',
    expTaste: 9.0,
    actTaste: 7.8,
    submittedBy: 'Vikram Nair',
    version: 'v3.0',
    status: 'Pending',
    risk: 'Medium',
    remarks: 'Oil temperature was slightly higher than target, affecting crispness.',
    files: ['temp_log.csv']
  },
  {
    id: 'EXP-004',
    recipe: 'Kheer Creamy',
    batchNo: 'B-2024-004',
    date: 'Mar 10, 2024',
    temp: '90°C',
    timing: '45m',
    expTexture: 'Creamy',
    actTexture: 'Creamy',
    expYield: '96%',
    actYield: '96%',
    variance: 0.2,
    varianceStatus: 'Ideal - perfect match',
    expTaste: 9.5,
    actTaste: 9.5,
    submittedBy: 'Sanjay Dutt',
    version: 'v2.2',
    status: 'Completed',
    risk: 'Low',
    remarks: 'Consistent reduction achieved. Flavor profile is spot on.',
    files: ['reduction_chart.pdf']
  }
]

export const auditLogs = [
  { id: 'LOG-001', expId: 'EXP-001', role: 'Manager', version: 'v3.2', action: 'Completed', timestamp: '2024-12-14 09:32', aiStatus: 'Pass', user: 'Arjun Mehta', details: 'All parameters within threshold. Texture and yield match predicted values. Hash verified: a1b2c3d4e5f6.' },
  { id: 'LOG-002', expId: 'EXP-002', role: 'Chef',    version: 'v2.1', action: 'Submitted', timestamp: '2024-12-13 14:18', aiStatus: 'Review', user: 'Priya Shah',  details: 'Variance detected in spice ratio. Awaiting quality review. Batch BATCH-2024-002 integrity confirmed.' },
  { id: 'LOG-003', expId: 'EXP-003', role: 'Manager', version: 'v5.0', action: 'Completed', timestamp: '2024-12-12 11:05', aiStatus: 'Fail', user: 'Arjun Mehta', details: 'Critical variance in cooking temperature. Texture inconsistency > 40%. Batch recalled.' },
  { id: 'LOG-004', expId: 'EXP-004', role: 'Chef',    version: 'v4.3', action: 'Completed', timestamp: '2024-12-11 16:44', aiStatus: 'Pass', user: 'Sunita Rao',  details: 'Excellent yield prediction accuracy. Taste score exceeded target. Cleared for production.' },
  { id: 'LOG-005', expId: 'EXP-005', role: 'Chef',    version: 'v1.8', action: 'Submitted', timestamp: '2024-12-10 10:22', aiStatus: 'Review', user: 'Vikram Nair', details: 'Batch number mismatch in ingredient logs. Manual cross-check required before approval.' },
  { id: 'LOG-001', expId: 'EXP-006', role: 'Manager', version: 'v3.0', action: 'Completed', timestamp: '2024-12-09 13:58', aiStatus: 'Pass', user: 'Arjun Mehta', details: 'All quality parameters passed. Recipe version 3.0 approved for scaling.' },
  { id: 'LOG-007', expId: 'EXP-007', role: 'Reviewer', version: 'v2.5', action: 'Completed', timestamp: '2024-12-08 15:30', aiStatus: 'Pass', user: 'Meena Joshi', details: 'Texture and flavor profiles match expected outputs. Approved with commendation.' },
  { id: 'LOG-008', expId: 'EXP-008', role: 'Manager', version: 'v1.2', action: 'Completed', timestamp: '2024-12-07 08:47', aiStatus: 'Fail', user: 'Arjun Mehta', details: 'Consistency issues detected. Mushy texture reported. Experiment failed quality threshold.' },
]

export const monthlyData = [
  { month: 'Jul', completed: 22, pending: 6 },
  { month: 'Aug', completed: 25, pending: 8 },
  { month: 'Sep', completed: 25, pending: 5 },
  { month: 'Oct', completed: 30, pending: 7 },
  { month: 'Nov', completed: 36, pending: 4 },
  { month: 'Dec', completed: 27, pending: 8 },
]

export const varianceData = [
  { day: 'Mon', score: 12 },
  { day: 'Tue', score: 8  },
  { day: 'Wed', score: 22 },
  { day: 'Thu', score: 6  },
  { day: 'Fri', score: 15 },
  { day: 'Sat', score: 9  },
  { day: 'Sun', score: 4  },
]



