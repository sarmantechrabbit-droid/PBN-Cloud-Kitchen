import { NavLink, useLocation } from "react-router-dom";
import {
  LayoutDashboard,
  ChefHat,
  ShieldCheck,
  Brain,
  FileText,
  Settings,
  HelpCircle,
  LogOut,
  Menu,
  ChevronRight,
} from "lucide-react";

import { Type } from "lucide-react";

const navItems = [
  {
    to: "/",
    label: "Dashboard",
    icon: <LayoutDashboard size={18} />,
    roles: ["Manager"],
  },
  {
    to: "/recipes",
    label: "Recipes",
    icon: <ChefHat size={18} />,
    roles: ["Chef"],
  },
  {
    to: "/quality",
    label: "Quality Review",
    icon: <ShieldCheck size={18} />,
    roles: ["Reviewer"],
  },
  {
    to: "/reviews",
    label: "Reviews",
    icon: <ShieldCheck size={18} />,
    roles: ["Manager", "Reviewer"],
  },
  {
    to: "/quality-builder",
    label: "Question Builder",
    icon: <Type size={18} />,
    roles: ["Manager"],
  },
  {
    to: "/ai",
    label: "AI Analysis",
    icon: <Brain size={18} />,
    roles: ["Manager", "CRA"],
  },
  {
    to: "/cra",
    label: "CRA Logs",
    icon: <FileText size={18} />,
    roles: ["CRA", "Manager"],
  },
  {
    to: "/all-recipes",
    label: "All Recipes",
    icon: <ChefHat size={18} />,
    roles: ["Chef", "Manager", "CRA"],
  },
];

export default function Sidebar({ collapsed, setCollapsed, onLogout }) {
  const location = useLocation();
  const role = localStorage.getItem("ck_role");
  const isChef = role === "Chef";
  const filteredItems = navItems.filter((item) => item.roles?.includes(role));

  return (
    <aside
      style={{
        width: collapsed ? 64 : 220,
        minHeight: "100vh",
        background: "var(--sidebar-bg)",
        borderRight: "1px solid var(--border)",
        display: "flex",
        flexDirection: "column",
        transition: "width 0.25s cubic-bezier(0.4,0,0.2,1)",
        position: "fixed",
        top: 0,
        left: 0,
        zIndex: 100,
        overflowX: "hidden",
      }}
    >
      {/* Logo */}
      <div
        style={{
          padding: "18px 14px",
          display: "flex",
          alignItems: "center",
          gap: 12,
          borderBottom: "1px solid var(--border)",
          minHeight: 64,
        }}
      >
        <div
          style={{
            minWidth: 36,
            height: 36,
            background: "var(--primary)",
            borderRadius: 10,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            boxShadow: "0 4px 14px var(--primary-glow-strong)",
            flexShrink: 0,
          }}
        >
          <ChefHat size={18} color="#fff" />
        </div>
        {!collapsed && (
          <div style={{ overflow: "hidden" }}>
            <div
              style={{
                fontSize: 13,
                fontWeight: 800,
                color: "var(--text)",
                lineHeight: 1.2,
                whiteSpace: "nowrap",
              }}
            >
              PBN Cloud Kitchen
            </div>
            <div
              style={{
                fontSize: 10,
                color: "var(--muted)",
                marginTop: 2,
                whiteSpace: "nowrap",
              }}
            >
              Kitchen Admin
            </div>
          </div>
        )}
      </div>

      {/* Nav links */}
      <nav style={{ flex: 1, padding: "10px 8px", overflowY: "auto" }}>
        {!collapsed && filteredItems.length > 0 && (
          <div
            style={{
              fontSize: 10,
              fontWeight: 700,
              color: "var(--muted)",
              textTransform: "uppercase",
              letterSpacing: 1,
              padding: "4px 12px 10px",
            }}
          >
            Main Menu
          </div>
        )}
        {filteredItems.map((item) => {
          const isActive =
            location.pathname === item.to ||
            (item.to !== "/" && location.pathname.startsWith(item.to + "/"));
          return (
            <NavLink
              key={item.to}
              to={item.to}
              style={{
                textDecoration: "none",
                display: "block",
                marginBottom: 2,
              }}
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 12,
                  padding: "10px 12px",
                  borderRadius: 10,
                  background: isActive ? "var(--primary-glow)" : "transparent",
                  color: isActive ? "var(--primary)" : "var(--muted)",
                  fontWeight: isActive ? 700 : 500,
                  fontSize: 13,
                  borderLeft: isActive
                    ? "2px solid var(--primary)"
                    : "2px solid transparent",
                  transition: "all 0.15s",
                  cursor: "pointer",
                }}
                onMouseEnter={(e) => {
                  if (!isActive) {
                    e.currentTarget.style.background = "var(--surface-hover)";
                    e.currentTarget.style.color = "var(--text)";
                  }
                }}
                onMouseLeave={(e) => {
                  if (!isActive) {
                    e.currentTarget.style.background = "transparent";
                    e.currentTarget.style.color = "var(--muted)";
                  }
                }}
              >
                <span style={{ minWidth: 18, display: "flex" }}>
                  {item.icon}
                </span>
                {!collapsed && (
                  <>
                    <span style={{ whiteSpace: "nowrap", flex: 1 }}>
                      {item.to === "/recipes" && isChef
                        ? "Create Experiment"
                        : item.label}
                    </span>
                    {isActive && <ChevronRight size={13} />}
                  </>
                )}
              </div>
            </NavLink>
          );
        })}
      </nav>

      {/* Bottom */}
      <div
        style={{ padding: "10px 8px", borderTop: "1px solid var(--border)" }}
      >
        {/* {role !== "Reviewer" && role !== "CRA" && (
          <button className="nav-item" style={{ marginBottom: 2 }}>
            <span style={{ minWidth: 18, display: "flex" }}>
              <Settings size={16} />
            </span>
            {!collapsed && (
              <span style={{ whiteSpace: "nowrap" }}>Settings</span>
            )}
          </button>
        )} */}
        {/* <button className="nav-item" style={{ marginBottom: 2 }}>
          <span style={{ minWidth: 18, display: "flex" }}>
            <HelpCircle size={16} />
          </span>
          {!collapsed && (
            <span style={{ whiteSpace: "nowrap" }}>Help & Docs</span>
          )}
        </button> */}
        <button
          onClick={onLogout}
          className="nav-item"
          style={{ color: "var(--danger)", marginBottom: 2 }}
        >
          <span style={{ minWidth: 18, display: "flex" }}>
            <LogOut size={16} />
          </span>
          {!collapsed && <span style={{ whiteSpace: "nowrap" }}>Logout</span>}
        </button>
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="nav-item"
          style={{ marginTop: 4 }}
        >
          <span style={{ minWidth: 18, display: "flex" }}>
            <Menu
              size={16}
              style={{
                transform: collapsed ? "rotate(180deg)" : "none",
                transition: "transform 0.25s",
              }}
            />
          </span>
          {!collapsed && <span style={{ whiteSpace: "nowrap" }}>Collapse</span>}
        </button>
      </div>
    </aside>
  );
}
