import React, { useState } from "react";
import {
  Search,
  Filter,
  ChefHat,
  Clock,
  Star,
  ArrowRight,
  LayoutGrid,
  List,
  X,
  Shield,
  Activity,
  Zap,
} from "lucide-react";
import PageHeader from "../../components/ui/PageHeader";
import StatusBadge from "../../components/ui/StatusBadge";
import { experiments } from "../../data/dummy";

const RecipeDetailModal = ({ recipe, onClose }) => {
  if (!recipe) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in shadow-2xl">
      <div
        className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl border shadow-2xl animate-slide-up"
        style={{ background: "var(--surface)", borderColor: "var(--border)" }}
      >
        {/* Header */}
        <div
          className="sticky top-0 p-6 border-b flex items-center justify-between z-10"
          style={{ background: "var(--surface)", borderColor: "var(--border)" }}
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-orange-500/10 flex items-center justify-center text-orange-500">
              <ChefHat size={24} />
            </div>
            <div>
              <h2
                className="text-xl font-bold"
                style={{ color: "var(--text)" }}
              >
                {recipe.recipe}
              </h2>
              <div className="flex items-center gap-2 mt-1">
                <StatusBadge status={recipe.status} />
                <span
                  className="text-xs font-mono"
                  style={{ color: "var(--muted)" }}
                >
                  {recipe.id}
                </span>
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-[var(--surface-hover)] rounded-full transition-colors"
            style={{ color: "var(--muted)" }}
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {/* Left Column: Basic Info */}
            <div className="space-y-4">
              <h3
                className="text-xs font-bold uppercase tracking-wider"
                style={{ color: "var(--primary)" }}
              >
                Core Parameters
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {[
                  {
                    label: "Batch No.",
                    value: recipe.batchNo,
                    icon: <Shield size={14} />,
                  },
                  {
                    label: "Chef",
                    value: recipe.chef,
                    icon: <ChefHat size={14} />,
                  },
                  {
                    label: "Temperature",
                    value: `${recipe.temp}°C`,
                    icon: <Activity size={14} />,
                  },
                  {
                    label: "Duration",
                    value: `${recipe.timing} mins`,
                    icon: <Clock size={14} />,
                  },
                ].map((item) => (
                  <div
                    key={item.label}
                    className="p-3 rounded-xl border"
                    style={{
                      background: "var(--bg)",
                      borderColor: "var(--border)",
                    }}
                  >
                    <div
                      className="flex items-center gap-2 mb-1"
                      style={{ color: "var(--muted)" }}
                    >
                      {item.icon}
                      <span className="text-[10px] font-bold uppercase tracking-tighter">
                        {item.label}
                      </span>
                    </div>
                    <div
                      className="text-sm font-bold"
                      style={{ color: "var(--text)" }}
                    >
                      {item.value}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right Column: AI Insights */}
            <div className="space-y-4">
              <h3
                className="text-xs font-bold uppercase tracking-wider"
                style={{ color: "var(--primary)" }}
              >
                AI Health Check
              </h3>
              <div
                className="p-4 rounded-xl border flex flex-col gap-4"
                style={{
                  background: "var(--bg)",
                  borderColor: "var(--border)",
                }}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Zap size={16} className="text-orange-500" />
                    <span
                      className="text-sm font-bold"
                      style={{ color: "var(--text)" }}
                    >
                      Overall AI Score
                    </span>
                  </div>
                  <span className="text-xl font-black text-orange-500">
                    {recipe.aiScore}%
                  </span>
                </div>
                {/* Score bar */}
                <div className="h-2 w-full bg-[var(--border)] rounded-full overflow-hidden">
                  <div
                    className="h-full bg-orange-500"
                    style={{ width: `${recipe.aiScore}%` }}
                  />
                </div>
                <div className="grid grid-cols-2 gap-x-6 gap-y-2">
                  <div className="flex justify-between text-xs">
                    <span style={{ color: "var(--muted)" }}>Texture Match</span>
                    <span className="font-bold text-green-500">92%</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span style={{ color: "var(--muted)" }}>Yield Pred.</span>
                    <span className="font-bold text-orange-500">88%</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Activity Timeline */}
          <div className="space-y-4">
            <h3
              className="text-xs font-bold uppercase tracking-wider"
              style={{ color: "var(--primary)" }}
            >
              Activity Timeline
            </h3>
            <div
              className="space-y-6 pl-2 border-l-2 ml-2"
              style={{ borderColor: "var(--border)" }}
            >
              {[
                {
                  title: "Quality Review Processed",
                  date: recipe.date,
                  desc: `AI analysis completed with ${recipe.aiScore}% variance match.`,
                  active: true,
                },
                {
                  title: "Experiment Submitted",
                  date: recipe.date,
                  desc: `Chef ${recipe.chef} submitted initial batch ${recipe.batchNo}.`,
                  active: false,
                },
              ].map((item, i) => (
                <div key={i} className="relative pl-6">
                  <div
                    className={`absolute -left-[33px] top-1 w-4 h-4 rounded-full border-4 ${item.active ? "bg-orange-500 border-orange-500/20" : "bg-[var(--border)] border-[var(--surface)]"}`}
                  />
                  <div className="flex flex-col">
                    <span
                      className="text-sm font-bold"
                      style={{ color: "var(--text)" }}
                    >
                      {item.title}
                    </span>
                    <span
                      className="text-[10px] mt-1"
                      style={{ color: "var(--muted)" }}
                    >
                      {item.date}
                    </span>
                    <p
                      className="text-xs mt-2"
                      style={{ color: "var(--subtle)" }}
                    >
                      {item.desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div
          className="p-6 border-t flex justify-end gap-3"
          style={{ background: "var(--bg)", borderColor: "var(--border)" }}
        >
          {/* <button 
            onClick={onClose}
            className="px-6 py-2 rounded-xl text-sm font-bold border hover:bg-[var(--surface-hover)] transition-all"
            style={{ background: 'var(--surface)', borderColor: 'var(--border)', color: 'var(--muted)' }}
          >
            Close
          </button>
          <button className="btn-primary">
            View Analytics
          </button> */}
        </div>
      </div>
    </div>
  );
};

const VersionListModal = ({ versions, baseName, onClose, onSelect }) => {
  if (!versions || versions.length === 0) return null;
  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div
        className="w-full max-w-lg rounded-2xl border shadow-2xl animate-slide-up"
        style={{ background: "var(--surface)", borderColor: "var(--border)" }}
      >
        <div
          className="p-5 border-b flex items-center justify-between"
          style={{ borderColor: "var(--border)" }}
        >
          <div>
            <h3 className="text-lg font-bold" style={{ color: "var(--text)" }}>
              Recipe Versions
            </h3>
            <div className="text-xs" style={{ color: "var(--muted)" }}>
              {baseName}
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-[var(--surface-hover)] rounded-full transition-colors"
            style={{ color: "var(--muted)" }}
          >
            <X size={18} />
          </button>
        </div>
        <div className="p-4 space-y-2 max-h-[60vh] overflow-y-auto">
          {versions.map((v) => (
            <button
              key={v.id}
              onClick={() => onSelect(v)}
              className="w-full text-left p-3 rounded-xl border flex items-center justify-between hover:bg-[var(--surface-hover)] transition-colors"
              style={{ borderColor: "var(--border)" }}
            >
              <div className="flex flex-col">
                <span className="text-sm font-semibold" style={{ color: "var(--text)" }}>
                  {v.recipe}
                </span>
                <span className="text-[11px]" style={{ color: "var(--muted)" }}>
                  {v.version}
                </span>
              </div>
              <span
                className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                  v.status === "Completed"
                    ? "bg-green-500/10 text-green-600"
                    : "bg-yellow-500/10 text-yellow-600"
                }`}
              >
                {v.status}
              </span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

const VersionDetailModal = ({ recipe, onClose }) => {
  if (!recipe) return null;
  const ingredients = recipe.ingredients || [];
  return (
    <div className="fixed inset-0 z-[130] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div
        className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl border shadow-2xl animate-slide-up"
        style={{ background: "var(--surface)", borderColor: "var(--border)" }}
      >
        <div
          className="sticky top-0 p-6 border-b flex items-center justify-between z-10"
          style={{ background: "var(--surface)", borderColor: "var(--border)" }}
        >
          <div>
            <h2 className="text-xl font-bold" style={{ color: "var(--text)" }}>
              Recipe Details
            </h2>
            <div className="text-xs mt-1" style={{ color: "var(--muted)" }}>
              {recipe.recipe} • {recipe.version}
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-[var(--surface-hover)] rounded-full transition-colors"
            style={{ color: "var(--muted)" }}
          >
            <X size={18} />
          </button>
        </div>
        <div className="p-6 space-y-6">
          <div className="grid grid-cols-2 gap-4">
            {[
              ["Recipe Name", recipe.recipe],
              ["Version", recipe.version],
              ["Status", recipe.status],
              ["Chef", recipe.chef],
            ].map(([label, value]) => (
              <div key={label} className="p-3 rounded-xl border" style={{ borderColor: "var(--border)", background: "var(--bg)" }}>
                <div className="text-[10px] font-bold uppercase" style={{ color: "var(--muted)" }}>
                  {label}
                </div>
                <div className="text-sm font-semibold" style={{ color: "var(--text)" }}>
                  {value || "—"}
                </div>
              </div>
            ))}
          </div>

          <div>
            <h4 className="text-sm font-bold mb-2" style={{ color: "var(--text)" }}>
              Ingredients
            </h4>
            {ingredients.length === 0 ? (
              <div className="text-xs italic" style={{ color: "var(--muted)" }}>
                No ingredients recorded.
              </div>
            ) : (
              <div className="space-y-2">
                {ingredients.map((ing, idx) => (
                  <div
                    key={`${ing.name}-${idx}`}
                    className="p-2 rounded-lg border flex items-center justify-between"
                    style={{ borderColor: "var(--border)", background: "var(--bg)" }}
                  >
                    <span className="text-sm font-semibold" style={{ color: "var(--text)" }}>
                      {ing.name || "—"}
                    </span>
                    <span className="text-xs" style={{ color: "var(--muted)" }}>
                      {ing.quantity || "—"} {ing.unit || ""}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="p-3 rounded-xl border" style={{ borderColor: "var(--border)", background: "var(--bg)" }}>
              <div className="text-[10px] font-bold uppercase" style={{ color: "var(--muted)" }}>
                Expected Output
              </div>
              <div className="text-sm font-semibold" style={{ color: "var(--text)" }}>
                {recipe.expOutputValue ? `${recipe.expOutputValue} ${recipe.expOutputUnit}` : "—"}
              </div>
            </div>
            <div className="p-3 rounded-xl border" style={{ borderColor: "var(--border)", background: "var(--bg)" }}>
              <div className="text-[10px] font-bold uppercase" style={{ color: "var(--muted)" }}>
                Actual Output
              </div>
              <div className="text-sm font-semibold" style={{ color: "var(--text)" }}>
                {recipe.actOutputValue ? `${recipe.actOutputValue} ${recipe.actOutputUnit}` : "—"}
              </div>
            </div>
          </div>

          <div className="p-4 rounded-xl border" style={{ borderColor: "var(--border)", background: "var(--bg)" }}>
            <div className="text-[10px] font-bold uppercase mb-1" style={{ color: "var(--muted)" }}>
              Chef Notes / Remarks
            </div>
            <div className="text-sm" style={{ color: "var(--text)" }}>
              {recipe.remarks || "—"}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default function AllRecipesPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("All");
  const [viewMode, setViewMode] = useState("grid");
  const [selectedRecipe, setSelectedRecipe] = useState(null);
  const [selectedBase, setSelectedBase] = useState(null);
  const [selectedVersion, setSelectedVersion] = useState(null);
  const [storedExperiments] = useState(() => {
    try {
      const raw = localStorage.getItem("ck_experiments");
      const parsed = raw ? JSON.parse(raw) : [];
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  });

  const allRecipes = [...storedExperiments, ...experiments];

  const normalizeRecipeName = (name) =>
    (name || "").replace(/\sv\d+\.\d+$/i, "").trim().toLowerCase();

  const getVersionsForRecipe = (recipeName) => {
    const base = normalizeRecipeName(recipeName);
    const matched = allRecipes.filter(
      (r) => normalizeRecipeName(r.recipe) === base,
    );
    const byVersion = new Map();
    matched.forEach((r) => {
      if (!byVersion.has(r.version)) {
        byVersion.set(r.version, r);
      }
    });
    return Array.from(byVersion.values()).sort((a, b) =>
      a.version > b.version ? -1 : 1,
    );
  };

  const filteredRecipes = allRecipes.filter((recipe) => {
    const matchesSearch =
      recipe.recipe.toLowerCase().includes(searchTerm.toLowerCase()) ||
      recipe.chef.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus =
      filterStatus === "All" || recipe.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  return (
    <div
      className="animate-fade-in p-4 lg:p-8 min-h-screen transition-colors duration-300"
      style={{ background: "var(--app-bg)" }}
    >
      <PageHeader
        title="All Recipes"
        subtitle="Explore and manage the complete collection of cloud kitchen recipes and experiments."
      />

      {/* Filters, Search & View Toggle */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div className="flex flex-col md:flex-row gap-4 flex-1">
          <div className="relative flex-1 max-w-md">
            <Search
              className="absolute left-3 top-1/2 -translate-y-1/2"
              size={18}
              style={{ color: "var(--muted)" }}
            />
            <input
              type="text"
              placeholder="Search recipes or chefs..."
              style={{
                background: "var(--surface)",
                borderColor: "var(--border)",
                color: "var(--text)",
              }}
              className="w-full pl-10 pr-4 py-2.5 border rounded-xl focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 outline-none transition-all text-sm shadow-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-1 md:pb-0">
            {["All", "Completed", "Pending"].map((status) => (
              <button
                key={status}
                onClick={() => setFilterStatus(status)}
                className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all whitespace-nowrap border shadow-sm ${
                  filterStatus === status
                    ? "bg-orange-500 text-white border-orange-500 shadow-orange-500/20"
                    : "hover:bg-[var(--surface-hover)]"
                }`}
                style={{
                  background:
                    filterStatus === status ? "#F97316" : "var(--surface)",
                  color: filterStatus === status ? "#fff" : "var(--muted)",
                  borderColor:
                    filterStatus === status ? "#F97316" : "var(--border)",
                }}
              >
                {status}
              </button>
            ))}
          </div>
        </div>

        {/* View Toggle Buttons */}
        <div className="flex items-center bg-[var(--surface)] border border-[var(--border)] rounded-xl p-1 shadow-sm">
          <button
            onClick={() => setViewMode("grid")}
            className={`p-2 rounded-lg transition-all ${viewMode === "grid" ? "bg-orange-500 text-white shadow-md" : "text-[var(--muted)] hover:bg-[var(--surface-hover)]"}`}
          >
            <LayoutGrid size={18} />
          </button>
          <button
            onClick={() => setViewMode("table")}
            className={`p-2 rounded-lg transition-all ${viewMode === "table" ? "bg-orange-500 text-white shadow-md" : "text-[var(--muted)] hover:bg-[var(--surface-hover)]"}`}
          >
            <List size={18} />
          </button>
        </div>
      </div>

      {/* Grid View */}
      {viewMode === "grid" && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredRecipes.map((recipe) => (
            <div
              key={recipe.id}
              style={{
                background: "var(--surface)",
                borderColor: "var(--border)",
              }}
              className="group border rounded-2xl overflow-hidden hover:border-orange-500/30 hover:shadow-xl hover:shadow-orange-500/5 transition-all duration-300 flex flex-col shadow-sm"
            >
              {/* Minimalist Card Header */}
              <div className="p-5 flex-1">
                <div className="flex items-center justify-between mb-4">
                  <StatusBadge status={recipe.status} />
                  <span
                    className="text-[10px] font-mono tracking-tighter"
                    style={{ color: "var(--muted)" }}
                  >
                    {recipe.id}
                  </span>
                </div>

                <h3
                  className="text-lg font-bold mb-2 truncate group-hover:text-orange-500 transition-colors"
                  style={{ color: "var(--text)" }}
                >
                  {recipe.recipe}
                </h3>

                <div className="flex items-center gap-2 mb-4">
                  <div className="w-6 h-6 rounded-full bg-orange-500/20 flex items-center justify-center text-[10px] font-bold text-orange-500">
                    {recipe.chef
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </div>
                  <span
                    className="text-xs font-medium"
                    style={{ color: "var(--muted)" }}
                  >
                    {recipe.chef}
                  </span>
                </div>

                <div
                  className="grid grid-cols-2 gap-3 pb-4 border-b"
                  style={{ borderColor: "var(--border)" }}
                >
                  <div className="flex items-center gap-2">
                    <Clock size={14} style={{ color: "var(--muted)" }} />
                    <span
                      className="text-xs font-semibold"
                      style={{ color: "var(--subtle)" }}
                    >
                      {recipe.timing}m
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Star size={14} style={{ color: "var(--muted)" }} />
                    <span
                      className="text-xs font-semibold"
                      style={{ color: "var(--subtle)" }}
                    >
                      {recipe.aiScore}%
                    </span>
                  </div>
                </div>
              </div>

              {/* Card Footer */}
              <div
                className="px-5 py-4 flex items-center justify-between border-t"
                style={{
                  background: "var(--bg)",
                  borderColor: "var(--border)",
                }}
              >
                <div className="flex flex-col">
                  <span
                    className="text-[10px] uppercase tracking-widest font-bold"
                    style={{ color: "var(--muted)" }}
                  >
                    Created On
                  </span>
                  <span
                    className="text-xs font-semibold"
                    style={{ color: "var(--text)" }}
                  >
                    {recipe.date}
                  </span>
                </div>
                <button
                  onClick={() => {
                    const versions = getVersionsForRecipe(recipe.recipe);
                    setSelectedBase({
                      name: recipe.recipe.replace(/\sv\d+\.\d+$/i, ""),
                      versions,
                    });
                  }}
                  className="p-2 border hover:bg-orange-500 hover:text-white rounded-lg transition-all duration-300 shadow-sm"
                  style={{
                    background: "var(--surface)",
                    borderColor: "var(--border)",
                    color: "var(--muted)",
                  }}
                >
                  <ArrowRight size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Table View */}
      {viewMode === "table" && (
        <div
          style={{ background: "var(--surface)", borderColor: "var(--border)" }}
          className="border rounded-2xl overflow-hidden shadow-sm"
        >
          <div className="overflow-x-auto">
            <table className="table">
              <thead>
                <tr>
                  {[
                    "ID",
                    "Recipe Name",
                    "Chef",
                    "Timing",
                    "AI Score",
                    "Date",
                    "Action",
                  ].map((h) => (
                    <th key={h}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filteredRecipes.map((recipe) => (
                  <tr key={recipe.id} className="table-row">
                    <td className="table-cell-primary table-cell-mono">
                      {recipe.id}
                    </td>
                    <td style={{ fontWeight: 600 }}>{recipe.recipe}</td>
                    <td>
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full bg-orange-500/20 flex items-center justify-center text-[10px] font-bold text-orange-500">
                          {recipe.chef
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </div>
                        <span className="text-xs">{recipe.chef}</span>
                      </div>
                    </td>
                    <td>
                      <span className="font-semibold">{recipe.timing}m</span>
                    </td>
                    <td>
                      <span className="font-bold text-orange-500">
                        {recipe.aiScore}%
                      </span>
                    </td>
                    <td className="table-cell-muted font-mono">
                      {recipe.date}
                    </td>
                    <td>
                      <button
                        onClick={() => {
                          const versions = getVersionsForRecipe(recipe.recipe);
                          setSelectedBase({
                            name: recipe.recipe.replace(/\sv\d+\.\d+$/i, ""),
                            versions,
                          });
                        }}
                        className="p-1.5 border hover:bg-orange-500 hover:text-white rounded-lg transition-all duration-300"
                        style={{
                          background: "var(--bg)",
                          borderColor: "var(--border)",
                          color: "var(--muted)",
                        }}
                      >
                        <ArrowRight size={14} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal */}
      {selectedRecipe && (
        <RecipeDetailModal
          recipe={selectedRecipe}
          onClose={() => setSelectedRecipe(null)}
        />
      )}

      {selectedBase && (
        <VersionListModal
          baseName={selectedBase.name}
          versions={selectedBase.versions}
          onClose={() => setSelectedBase(null)}
          onSelect={(version) => {
            setSelectedVersion(version);
          }}
        />
      )}

      {selectedVersion && (
        <VersionDetailModal
          recipe={selectedVersion}
          onClose={() => setSelectedVersion(null)}
        />
      )}

      {filteredRecipes.length === 0 && (
        <div className="py-20 flex flex-col items-center justify-center text-center">
          <div
            className="w-16 h-16 border rounded-full flex items-center justify-center mb-4 shadow-sm"
            style={{
              background: "var(--surface)",
              borderColor: "var(--border)",
              color: "var(--muted)",
            }}
          >
            <ChefHat size={32} />
          </div>
          <h3 className="text-lg font-bold" style={{ color: "var(--text)" }}>
            No recipes found
          </h3>
          <p
            className="max-w-xs mt-2 text-sm italic"
            style={{ color: "var(--muted)" }}
          >
            Try adjusting your search or filters to find what you're looking
            for.
          </p>
        </div>
      )}
    </div>
  );
}
