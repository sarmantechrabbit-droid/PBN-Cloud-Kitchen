import {
  FlaskConical,
  CheckCircle,
  XCircle,
  Clock,
  Download,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import Card from "../../components/ui/Card";
import StatCard from "../../components/ui/StatCard";
import StatusBadge from "../../components/ui/StatusBadge";
import PageHeader from "../../components/ui/PageHeader";
import { experiments, monthlyData } from "../../data/dummy";

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div
      style={{
        background: "var(--surface)",
        border: "1px solid var(--border)",
        borderRadius: 10,
        padding: "10px 14px",
        fontSize: 12,
      }}
    >
      <div style={{ fontWeight: 700, color: "var(--text)", marginBottom: 6 }}>
        {label}
      </div>
      {payload.map((p) => (
        <div key={p.dataKey} style={{ color: p.color, marginBottom: 2 }}>
          {p.dataKey}: {p.value}
        </div>
      ))}
    </div>
  );
};

export default function DashboardPage() {
  const role = localStorage.getItem("ck_role");
  const chefKey = (localStorage.getItem("ck_auth_email") || "")
    .split("@")[0]
    .toLowerCase();
  const storedExperiments = (() => {
    try {
      const raw = localStorage.getItem("ck_experiments");
      const parsed = raw ? JSON.parse(raw) : [];
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  })();
  const allExperiments = [...storedExperiments, ...experiments];
  const chefExperiments =
    role === "Chef" && chefKey
      ? allExperiments.filter((e) =>
          String(e.chef || "")
            .toLowerCase()
            .includes(chefKey),
        )
      : allExperiments;

  const chartData =
    role === "Chef"
      ? monthlyData.map((m) => {
          const counts = chefExperiments.reduce(
            (acc, e) => {
              if (!e.date) return acc;
              const month = new Date(e.date).toLocaleString("en-US", {
                month: "short",
              });
              if (month !== m.month) return acc;
              if (e.status === "Completed") acc.completed += 1;
              if (e.status === "Pending") acc.pending += 1;
              return acc;
            },
            { completed: 0, pending: 0 },
          );
          return { ...m, ...counts };
        })
      : monthlyData;

  return (
    <div style={{ animation: "fadeIn 0.3s ease-out" }}>
      <PageHeader
        title="Dashboard"
        subtitle="Monitor your cloud kitchen experiment analytics and performance."
      />

      {/* Stat Cards */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(4,1fr)",
          gap: 16,
          marginBottom: 24,
        }}
      >
        <StatCard
          icon={<FlaskConical size={20} />}
          label="Total Experiments"
          value="86"
          trend="12.4%"
          trendUp
          sub="This month"
        />
        <StatCard
          icon={<CheckCircle size={20} />}
          label="Completed"
          value={monthlyData[5].completed}
          trend="8.2%"
          trendUp
          sub="Ready for production"
        />
        <StatCard
          icon={<Clock size={20} />}
          label="Pending Review"
          value="16"
          sub="Awaiting quality check"
        />
        <StatCard
          icon={<FlaskConical size={20} />}
          label="Monthly Success Experiments"
          value="82%"
          trend="4.5%"
          trendUp
          sub="Current Month"
        />
      </div>

      {/* Monthly Experiment Highlight Card */}
      {/* <Card style={{ 
        marginBottom: 24, 
        background: 'linear-gradient(135deg, var(--primary-glow) 0%, var(--surface) 100%)', 
        border: '1px solid rgba(var(--primary-rgb), 0.1)',
        overflow: 'hidden',
        position: 'relative'
      }}>
        <div style={{
          position: 'absolute', top: -20, right: -20, 
          width: 150, height: 150, borderRadius: '50%',
          background: 'var(--primary)', opacity: 0.05, filter: 'blur(40px)'
        }} />
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'relative', zIndex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
            <div style={{ 
              width: 54, height: 54, borderRadius: 16, 
              background: 'var(--primary)', color: '#fff',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: '0 8px 16px -4px rgba(var(--primary-rgb), 0.3)'
            }}>
              <FlaskConical size={28} />
            </div>
            <div>
              <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--primary)', textTransform: 'uppercase', letterSpacing: 1.2, marginBottom: 4 }}>Monthly Experiment Card</div>
              <div style={{ fontSize: 22, fontWeight: 800, color: 'var(--text)' }}>{experiments[0].recipe}</div>
              <div style={{ fontSize: 13, color: 'var(--muted)', marginTop: 2 }}>
                Best performing experiment in <strong>December 2024</strong> · 
                <span style={{ color: 'var(--success)', fontWeight: 600, marginLeft: 6 }}>{experiments[0].aiScore}% AI Accuracy</span>
              </div>
            </div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: 36, fontWeight: 900, color: 'var(--primary)', lineHeight: 1 }}>{experiments[0].aiScore}</div>
            <div style={{ fontSize: 11, fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase', marginTop: 4 }}>AI Reliability Score</div>
          </div>
        </div>
      </Card> */}

      {/* Charts */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1.6fr 1fr",
          gap: 16,
          marginBottom: 24,
        }}
      >
        {/* Bar Chart */}
        <Card>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              marginBottom: 20,
            }}
          >
            <div>
              <div
                style={{ fontSize: 15, fontWeight: 700, color: "var(--text)" }}
              >
                Experiment Outcomes
              </div>
              <div
                style={{ fontSize: 12, color: "var(--muted)", marginTop: 2 }}
              >
                Monthly breakdown — last 6 months
              </div>
            </div>
            <select
              style={{
                background: "var(--bg)",
                border: "1px solid var(--border)",
                color: "var(--muted)",
                borderRadius: 8,
                padding: "5px 10px",
                fontSize: 12,
                fontFamily: "inherit",
                outline: "none",
              }}
            >
              <option>Last 6 Months</option>
            </select>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={chartData} barGap={4} barCategoryGap="30%">
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="var(--border)"
                vertical={false}
              />
              <XAxis
                dataKey="month"
                tick={{ fill: "var(--muted)", fontSize: 12 }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                tick={{ fill: "var(--muted)", fontSize: 12 }}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip content={<CustomTooltip />} />
              <Bar
                dataKey="completed"
                fill="var(--success)"
                radius={[6, 6, 0, 0]}
              />
              <Bar
                dataKey="pending"
                fill="var(--warning)"
                radius={[6, 6, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
          <div style={{ display: "flex", gap: 18, marginTop: 12 }}>
            {[
              ["Completed", "var(--success)"],
              ["Pending", "var(--warning)"],
            ].map(([l, c]) => (
              <div
                key={l}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 6,
                  fontSize: 11,
                  color: "var(--muted)",
                }}
              >
                <div
                  style={{
                    width: 8,
                    height: 8,
                    borderRadius: 2,
                    background: c,
                  }}
                />
                {l}
              </div>
            ))}
          </div>
        </Card>

        {/* Monthly Experiment Summary Card */}
        <Card>
          <div
            style={{
              fontSize: 15,
              fontWeight: 700,
              color: "var(--text)",
              marginBottom: 4,
            }}
          >
            Monthly Experiment Summary
          </div>
          <div
            style={{ fontSize: 12, color: "var(--muted)", marginBottom: 16 }}
          >
            Performance metrics for {monthlyData[5].month}
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: 12,
              marginBottom: 16,
            }}
          >
            <div
              style={{
                background: "var(--bg)",
                padding: 12,
                borderRadius: 10,
                border: "1px solid var(--border)",
              }}
            >
              <div
                style={{
                  fontSize: 10,
                  color: "var(--muted)",
                  fontWeight: 700,
                  textTransform: "uppercase",
                  marginBottom: 4,
                }}
              >
                Completed
              </div>
              <div
                style={{
                  fontSize: 18,
                  fontWeight: 800,
                  color: "var(--success)",
                }}
              >
                {monthlyData[5].completed}
              </div>
            </div>
            <div
              style={{
                background: "var(--bg)",
                padding: 12,
                borderRadius: 10,
                border: "1px solid var(--border)",
              }}
            >
              <div
                style={{
                  fontSize: 10,
                  color: "var(--muted)",
                  fontWeight: 700,
                  textTransform: "uppercase",
                  marginBottom: 4,
                }}
              >
                Pending
              </div>
              <div
                style={{
                  fontSize: 18,
                  fontWeight: 800,
                  color: "var(--warning)",
                }}
              >
                {monthlyData[5].pending}
              </div>
            </div>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {[
              {
                label: "Completed",
                value: monthlyData[5].completed,
                color: "var(--success)",
              },
              {
                label: "Pending",
                value: monthlyData[5].pending,
                color: "var(--warning)",
              },
            ].map((d) => (
              <div
                key={d.label}
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                }}
              >
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 8,
                    fontSize: 12,
                    color: "var(--muted)",
                  }}
                >
                  <div
                    style={{
                      width: 8,
                      height: 8,
                      borderRadius: "50%",
                      background: d.color,
                    }}
                  />
                  {d.label}
                </div>
                <span
                  style={{
                    fontSize: 13,
                    fontWeight: 700,
                    color: "var(--text)",
                  }}
                >
                  {d.value}
                </span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Experiments Table */}
      <Card noPad>
        <div
          style={{
            padding: "18px 24px",
            borderBottom: "1px solid var(--border)",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <div>
            <div
              style={{ fontSize: 15, fontWeight: 700, color: "var(--text)" }}
            >
              Recent Experiments
            </div>
            <div style={{ fontSize: 12, color: "var(--muted)", marginTop: 2 }}>
              Latest cooking experiments submitted
            </div>
          </div>
          <button
            className="btn-primary"
            style={{ display: "flex", alignItems: "center", gap: 6 }}
          >
            <Download size={13} /> Export
          </button>
        </div>
        <div style={{ overflowX: "auto" }}>
          <table className="table">
            <thead>
              <tr>
                {["Exp ID", "Recipe", "Date", "Chef", "AI Score"].map((h) => (
                  <th key={h}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {experiments.map((e) => (
                <tr key={e.id} className="table-row">
                  <td className="table-cell-primary">{e.id}</td>
                  <td style={{ fontWeight: 500 }}>{e.recipe}</td>
                  <td className="table-cell-muted">{e.date}</td>
                  <td>
                    <div
                      style={{ display: "flex", alignItems: "center", gap: 8 }}
                    >
                      <div
                        style={{
                          width: 26,
                          height: 26,
                          borderRadius: "50%",
                          background: "var(--primary-glow)",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          fontSize: 9,
                          fontWeight: 800,
                          color: "var(--primary)",
                        }}
                      >
                        {e.chef
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </div>
                      <span style={{ fontSize: 13, color: "var(--text)" }}>
                        {e.chef}
                      </span>
                    </div>
                  </td>
                  <td>
                    <div
                      style={{ display: "flex", alignItems: "center", gap: 8 }}
                    >
                      <div
                        style={{
                          width: 52,
                          height: 4,
                          background: "var(--bg)",
                          borderRadius: 2,
                        }}
                      >
                        <div
                          style={{
                            height: "100%",
                            borderRadius: 2,
                            width: `${e.aiScore}%`,
                            background:
                              e.aiScore > 80
                                ? "var(--success)"
                                : e.aiScore > 60
                                  ? "var(--warning)"
                                  : "var(--danger)",
                          }}
                        />
                      </div>
                      <span
                        style={{
                          fontSize: 12,
                          fontWeight: 700,
                          color: "var(--text)",
                        }}
                      >
                        {e.aiScore}
                      </span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
