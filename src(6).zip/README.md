# 🍳 PBN Cloud Kitchen — Admin Dashboard

A modern, production-grade React admin dashboard for managing cloud kitchen cooking experiments, AI analysis, and quality audits.

---

## 🚀 Quick Start

### 1. Install dependencies
```bash
cd pbn-cloud-kitchen-dashboard
npm install
```

### 2. Run development server
```bash
npm run dev
```
Open http://localhost:5173

### 3. Build for production
```bash
npm run build
```

---

## 📁 Project Structure

```
src/
├── components/
│   ├── layout/
│   │   ├── Sidebar.jsx          ← Collapsible sidebar with react-router NavLinks
│   │   └── Navbar.jsx           ← Top bar: search, notifications, user menu
│   ├── ui/
│   │   ├── Card.jsx             ← Reusable surface card
│   │   ├── StatCard.jsx         ← Metric stat card with trend indicator
│   │   ├── StatusBadge.jsx      ← Colored pill badge (Approved/Rejected/Pending/Risk)
│   │   ├── Modal.jsx            ← Generic modal with backdrop blur
│   │   ├── LogoutModal.jsx      ← Confirm logout dialog
│   │   └── PageHeader.jsx       ← Page title + subtitle + actions slot
│   ├── forms/
│   │   ├── FormInput.jsx        ← Styled labeled input with optional icon
│   │   └── FileUploader.jsx     ← Drag & drop file upload with file list
├── pages/
│   ├── dashboard/
│   │   └── DashboardPage.jsx    ← Analytics overview, charts, experiments table
│   ├── recipes/
│   │   └── RecipePage.jsx       ← 4-step experiment creation wizard
│   ├── quality/
│   │   └── QualityPage.jsx      ← Review queue, log viewer, approve/reject
│   ├── ai/
│   │   └── AIPage.jsx           ← AI variance table: search, sort, filter, paginate
│   └── cra/
│       └── CRAPage.jsx          ← Audit logs with expandable detail rows
├── data/
│   └── dummy.js                 ← All mock data (experiments, AI, logs, charts)
├── styles/
│   ├── globals.css              ← Tailwind base + CSS variables + component classes
│   └── theme.js                 ← Design token JS object
├── App.jsx                      ← Root layout + React Router routes
└── main.jsx                     ← Vite entry point
```

---

## 🎨 Color System (CSS Variables)

| Variable             | Value      | Usage                          |
|----------------------|------------|--------------------------------|
| `--primary`          | `#F97316`  | Brand orange, CTAs, accents    |
| `--bg`               | `#0F1117`  | App background                 |
| `--surface`          | `#1A1D27`  | Cards, sidebar, navbar         |
| `--border`           | `#2A2D3E`  | Dividers, input borders        |
| `--success`          | `#22C55E`  | Approved, Pass, Low risk       |
| `--danger`           | `#EF4444`  | Rejected, Fail, High risk      |
| `--warning`          | `#F59E0B`  | Pending, Review, Medium risk   |
| `--info`             | `#3B82F6`  | Informational states           |
| `--text`             | `#F1F5F9`  | Primary text                   |
| `--muted`            | `#64748B`  | Secondary / label text         |

---

## 📄 Pages

| Page        | Route        | Description                                    |
|-------------|--------------|------------------------------------------------|
| Dashboard   | `/`          | Stats, bar+pie charts, experiments table       |
| Recipes     | `/recipes`   | 4-step experiment creation form with wizard UI |
| Quality     | `/quality`   | Review queue + AI analysis + approve/reject    |
| AI Analysis | `/ai`        | Sortable/filterable/paginated variance table   |
| CRA Logs    | `/cra`       | Immutable audit log with expandable rows       |

---

## 📦 Dependencies

```json
{
  "react": "^18",
  "react-dom": "^18",
  "react-router-dom": "^6",
  "recharts": "^2",
  "lucide-react": "^0.383",
  "framer-motion": "^11"
}
```
