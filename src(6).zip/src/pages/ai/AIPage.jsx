import { useState } from "react";
import {
  Search,
  Download,
  Filter,
  Activity,
  Shield,
  Star,
  Zap,
  ChevronDown,
  FileText,
  User,
  Thermometer,
  Clock,
  Layers,
  FlaskConical,
  CheckCircle2,
  AlertCircle,
  ChevronUp,
} from "lucide-react";
import Card from "../../components/ui/Card";
import StatCard from "../../components/ui/StatCard";
import StatusBadge from "../../components/ui/StatusBadge";
import PageHeader from "../../components/ui/PageHeader";
import { aiAnalysis } from "../../data/dummy";

export default function AIPage() {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("All");
  const role = localStorage.getItem("ck_role");

  const filtered = aiAnalysis.filter((a) => {
    const matchesSearch = 
      a.recipe.toLowerCase().includes(search.toLowerCase()) ||
      a.id.toLowerCase().includes(search.toLowerCase());
    const matchesFilter = filter === "All" || a.status === filter;
    return matchesSearch && matchesFilter;
  });

  const ExperimentCard = ({ data }) => {
    const [expanded, setExpanded] = useState(false);
    const barColor = data.variance < 5 ? "var(--success)" : data.variance < 15 ? "var(--warning)" : "var(--danger)";

    return (
      <Card style={{ marginBottom: 20, padding: 24 }}>
        {/* Header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
             <div style={{ width: 48, height: 48, borderRadius: 12, background: "var(--primary-glow)", display: "flex", alignItems: "center", justifyContent: "center", color: "var(--primary)" }}>
                <FlaskConical size={24} />
             </div>
             <div>
                <div style={{ fontSize: 18, fontWeight: 800, color: "var(--text)" }}>{data.recipe}</div>
                <div style={{ fontSize: 13, color: "var(--muted)", display: "flex", gap: 8 }}>
                  <span>{data.id}</span>
                  <span>•</span>
                  <span>Batch: {data.batchNo}</span>
                  <span>•</span>
                  <span>{data.date}</span>
                </div>
             </div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '4px 10px', background: 'var(--bg)', borderRadius: 20, border: '1px solid var(--border)', fontSize: 11, fontWeight: 700, color: 'var(--muted)' }}>
              <div style={{ width: 6, height: 6, borderRadius: '50%', background: data.risk === 'Low' ? 'var(--success)' : 'var(--warning)' }} />
              Risk: {data.risk}
            </div>
            <StatusBadge status={data.status} />
            <button
              onClick={() => setExpanded(!expanded)}
              style={{
                width: 32,
                height: 32,
                borderRadius: 8,
                border: "none",
                background: "var(--primary-glow)",
                color: "var(--primary)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                cursor: "pointer",
                transition: "all 0.2s",
                marginLeft: 4,
                transform: expanded ? 'rotate(180deg)' : 'none'
              }}
            >
              <ChevronDown size={14} />
            </button>
          </div>
        </div>

        {/* Metric Grid 1 */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 12, marginBottom: 24 }}>
          <MetricBox label="Temp" value={data.temp} icon={Thermometer} />
          <MetricBox label="Timing" value={data.timing} icon={Clock} />
          <MetricBox label="Exp. Texture" value={data.expTexture} icon={FlaskConical} />
          <MetricBox label="Act. Texture" value={data.actTexture} icon={Layers} color={data.expTexture !== data.actTexture ? "var(--warning)" : "var(--success)"} />
          <MetricBox label="Exp. Yield" value={data.expYield} icon={Zap} />
          <MetricBox label="Act. Yield" value={data.actYield} icon={Activity} />
        </div>

        {/* AI Variance Analysis Section */}
        <div style={{ marginBottom: expanded ? 24 : 0 }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: "var(--muted)", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 12 }}>AI Variance Analysis</div>
          <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
            <div style={{ fontSize: 32, fontWeight: 900, color: barColor }}>{data.variance}%</div>
            <div style={{ flex: 1 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 8, fontSize: 13, fontWeight: 600, color: "var(--text)" }}>
                {data.variance < 5 ? <CheckCircle2 size={14} color="var(--success)" /> : <AlertCircle size={14} color="var(--warning)" />}
                {data.varianceStatus}
              </div>
              <div style={{ height: 8, background: "var(--border)", borderRadius: 4, width: "100%", position: "relative" }}>
                 <div style={{ height: "100%", background: barColor, borderRadius: 4, width: `${Math.min(100, data.variance * 2)}%`, transition: "width 0.5s ease" }} />
              </div>
            </div>
          </div>
        </div>

        {expanded && (
          <div style={{ animation: 'fadeIn 0.3s ease-out' }}>
            {/* Metric Grid 2 */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 24 }}>
              <MetricBox label="Exp. Taste" value={`★ ${data.expTaste}`} icon={Star} />
              <MetricBox label="Act. Taste" value={`★ ${data.actTaste}`} icon={Star} color="var(--primary)" />
              <MetricBox label="Submitted by" value={data.submittedBy} icon={User} />
              <MetricBox label="Recipe Ver." value={data.version} icon={FileText} />
            </div>

            {/* Attached Files & Remarks */}
            <div style={{ borderTop: "1px solid var(--border)", paddingTop: 20, display: "flex", flexDirection: "column", gap: 16 }}>
               <div>
                 <div style={{ fontSize: 12, fontWeight: 700, color: "var(--muted)", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 8 }}>Attached Files</div>
                 <div style={{ display: "flex", gap: 8 }}>
                    {data.files.map(f => (
                      <div key={f} style={{ display: "flex", alignItems: "center", gap: 6, padding: "6px 12px", background: "var(--bg)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 12, color: "var(--text)", fontWeight: 500 }}>
                        <FileText size={14} color="var(--primary)" />
                        {f}
                      </div>
                    ))}
                 </div>
               </div>
               <div>
                 <div style={{ fontSize: 12, fontWeight: 700, color: "var(--muted)", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 8 }}>Reviewer Remarks</div>
                 <div style={{ padding: "12px 16px", background: "var(--bg)", border: "1px solid var(--border)", borderRadius: 10, fontSize: 13, color: "var(--muted)", lineHeight: 1.5 }}>
                   {data.remarks}
                 </div>
               </div>
            </div>
          </div>
        )}
      </Card>
    );
  };

  const MetricBox = ({ label, value, icon: Icon, color = "var(--text)" }) => (
    <div style={{ background: "var(--bg)", border: "1px solid var(--border)", borderRadius: 12, padding: "12px 14px" }}>
      <div style={{ fontSize: 11, color: "var(--muted)", fontWeight: 600, textTransform: "uppercase", marginBottom: 6, display: "flex", alignItems: "center", gap: 4 }}>
        <Icon size={12} color="var(--muted)" />
        {label}
      </div>
      <div style={{ fontSize: 14, fontWeight: 700, color }}>{value}</div>
    </div>
  );

  return (
    <div style={{ animation: "fadeIn 0.3s ease-out" }}>
      <PageHeader
        title="AI Analysis"
        subtitle="Approve or reject experiments based on granular AI variance data."
      />

      {/* Top Stat Row */}
      {role === "Manager" && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16, marginBottom: 24 }}>
          <StatCard icon={<Zap size={20} />} label="Yield Pred." value="94.8%" trend="1.2%" trendUp sub="Avg. Performance" />
          <StatCard icon={<Star size={20} />} label="Texture Match Rate" value="91%" trend="3.8%" trendUp sub="AI accuracy" />
          <StatCard icon={<Shield size={20} />} label="Total Predictions" value="156" sub="All time" />
          <StatCard icon={<Activity size={20} />} label="Total Experiments" value={aiAnalysis.length} sub="Analyzed items" />
        </div>
      )}

      {/* Toolbar & Filters */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <div style={{ fontSize: 15, fontWeight: 700, color: "var(--text)" }}> 
          {filtered.length} experiments awaiting review
        </div>
        <div style={{ display: "flex", gap: 8 }}>
            {["All", "Pending", "Completed"].map(f => (
               <button
                 key={f}
                 onClick={() => setFilter(f)}
                 style={{ 
                   padding: "8px 16px", borderRadius: 10, border: "none",
                   background: filter === f ? "var(--primary)" : "var(--bg)",
                   color: filter === f ? "#fff" : "var(--muted)",
                   fontSize: 13, fontWeight: 700, cursor: "pointer",
                   transition: "all 0.2s"
                 }}
               >
                 {f}
               </button>
            ))}
        </div>
      </div>

      <div style={{ marginBottom: 20, display: "flex", gap: 12 }}>
         <div style={{ position: "relative", flex: 1 }}>
            <Search size={14} style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", color: "var(--muted)" }} />
            <input 
              value={search} 
              onChange={e => setSearch(e.target.value)} 
              placeholder="Search experiments by name or ID..." 
              className="input-field" 
              style={{ paddingLeft: 36 }}
            />
         </div>
         <button className="btn-ghost" style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <Filter size={14} /> Filter
         </button>
         <button className="btn-primary" style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <Download size={14} /> Export Report
         </button>
      </div>

      {/* Experiment List */}
      <div>
        {filtered.map((e) => (
          <ExperimentCard key={e.id} data={e} />
        ))}
        {filtered.length === 0 && (
          <div style={{ padding: 60, textAlign: "center", color: "var(--muted)", background: "var(--surface)", borderRadius: 16, border: "1px dashed var(--border)" }}>
             No experiments found matching your criteria.
          </div>
        )}
      </div>
    </div>
  );
}
