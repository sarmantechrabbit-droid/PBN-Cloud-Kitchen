import { useState } from 'react'
import { Search, Bell, ChevronDown, RotateCcw, X } from 'lucide-react'
import ThemeToggle from '../ui/ThemeToggle'

const recentSearches = ['Butter Chicken v3.2', 'EXP-001 – Approved', 'Quality Review Queue', 'AI Variance Report']

export default function Navbar({ sidebarWidth, onLogout }) {
  const [search, setSearch] = useState('')
  const [focused, setFocused] = useState(false)

  return (
    <header style={{
      position: 'fixed', top: 0,
      left: sidebarWidth, right: 0, height: 64,
      zIndex: 90,
      background: 'var(--topbar-bg)',
      borderBottom: '1px solid var(--border)',
      display: 'flex', alignItems: 'center',
      padding: '0 24px', gap: 16,
      transition: 'left 0.25s cubic-bezier(0.4,0,0.2,1)',
    }}>
      {/* Search bar */}
      <div style={{ flex: 1, maxWidth: 400, position: 'relative' }}>
        <Search size={14} style={{
          position: 'absolute', left: 12, top: '50%',
          transform: 'translateY(-50%)',
          color: 'var(--muted)', pointerEvents: 'none',
        }} />
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => setTimeout(() => setFocused(false), 200)}
          placeholder="Search experiments, recipes, logs..."
          style={{
            width: '100%',
            background: 'var(--bg)',
            border: `1px solid ${focused ? 'var(--primary)' : 'var(--border)'}`,
            borderRadius: 10, padding: '8px 12px 8px 34px',
            color: 'var(--text)', fontSize: 13,
            outline: 'none', fontFamily: 'inherit',
            boxShadow: focused ? '0 0 0 3px var(--primary-glow)' : 'none',
            transition: 'all 0.2s',
          }}
        />
        {search && (
          <button onClick={() => setSearch('')} style={{
            position: 'absolute', right: 10, top: '50%',
            transform: 'translateY(-50%)',
            background: 'none', border: 'none',
            cursor: 'pointer', color: 'var(--muted)',
            display: 'flex', alignItems: 'center',
          }}>
            <X size={13} />
          </button>
        )}

        {/* Dropdown */}
        {focused && (
          <div style={{
            position: 'absolute', top: 'calc(100% + 8px)',
            left: 0, right: 0,
            background: '#fff', borderRadius: 12,
            boxShadow: '0 20px 60px rgba(0,0,0,0.3)',
            padding: 8, zIndex: 200,
          }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: '#999', textTransform: 'uppercase', letterSpacing: 1, padding: '6px 10px 4px' }}>
              Recent Searches
            </div>
            {recentSearches.map(s => (
              <div
                key={s}
                onClick={() => setSearch(s)}
                style={{
                  padding: '9px 12px', borderRadius: 8,
                  color: '#333', fontSize: 13, cursor: 'pointer',
                  display: 'flex', alignItems: 'center', gap: 10,
                  transition: 'background 0.1s',
                }}
                onMouseEnter={e => e.currentTarget.style.background = '#f5f5f5'}
                onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
              >
                <RotateCcw size={13} color="#999" />
                {s}
              </div>
            ))}
          </div>
        )}
      </div>

      <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 10 }}>
        {/* Theme toggle */}
        <ThemeToggle />

        {/* Notification bell */}
        <button style={{
          position: 'relative',
          background: 'var(--bg)', border: '1px solid var(--border)',
          borderRadius: 10, padding: 8, color: 'var(--muted)',
          cursor: 'pointer', display: 'flex', alignItems: 'center',
        }}>
          <Bell size={16} />
          <span style={{
            position: 'absolute', top: 6, right: 6,
            width: 7, height: 7, borderRadius: '50%',
            background: 'var(--primary)',
            border: '1.5px solid var(--surface)',
          }} />
        </button>

        {/* User badge */}
        <button
          onClick={onLogout}
          style={{
            display: 'flex', alignItems: 'center', gap: 10,
            padding: '6px 12px 6px 8px',
            background: 'var(--bg)',
            border: '1px solid var(--border)',
            borderRadius: 10, cursor: 'pointer',
            fontFamily: 'inherit',
            transition: 'all 0.15s',
          }}
          onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--primary)'; e.currentTarget.style.background = 'var(--primary-glow)' }}
          onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.background = 'var(--bg)' }}
        >
          <div style={{
            width: 30, height: 30, borderRadius: '50%',
            background: 'linear-gradient(135deg, var(--primary), var(--primary-dark))',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 11, fontWeight: 800, color: '#fff',
          }}>
            AK
          </div>
          <div style={{ textAlign: 'left' }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--text)' }}>Arjun Mehta</div>
            <div style={{ fontSize: 10, color: 'var(--muted)' }}>Admin</div>
          </div>
          <ChevronDown size={13} color="var(--muted)" />
        </button>
      </div>
    </header>
  )
}
